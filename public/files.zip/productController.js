const Product = require("../../models/productSchema");
const Category = require("../../models/categorySchema");
const Brand = require("../../models/brandSchema");
const User = require("../../models/userSchema");
const fs = require("fs");
const path = require("path");
const sharp = require("sharp");

const getProductAddPage = async (req, res) => {
  try {
    const category = await Category.find({ isListed: true });
    const brand = await Brand.find({ isBlocked: false });

    res.render("product-add", {
      cat: category,
      brand: brand,
    });
  } catch (error) {
    console.error("Error fetching product add page:", error);
    res.redirect("/admin/pageerror");
  }
};

const addProducts = async (req, res) => {
  try {
    const Products = req.body;
    const productExists = await Product.findOne({
      productName: Products.productName,
    });

    if (!productExists) {
      const images = [];

      //use an absolute path and ensure the folder exists:
      const outputDir = path.join(__dirname, "../../public/uploads/re-image");
      if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
      }

      if (req.files && req.files.length > 0) {
        for (let i = 0; i < req.files.length; i++) {
          const originalImagePath = req.files[i].path;
          const resizedImagePath = path.join(outputDir, req.files[i].filename);
          await sharp(originalImagePath)
            .resize({ width: 450, height: 450 })
            .toFile(resizedImagePath);
          images.push(req.files[i].filename);
        }
      }

      // FIX: findById() expects a raw id, not a query object.
      // Passing { name: ... } to findById either throws a CastError or
      // resolves to null, which was making every submission fail with
      // "Category not found" even for valid categories.
      const categoryId = await Category.findOne({ name: Products.category });
      if (!categoryId) {
        return res.status(400).send("Category not found");
      }
      const newProduct = new Product({
        productName: Products.productName,
        description: Products.description,
        brand: Products.brand,
        category: categoryId._id,
        regularPrice: Products.regularPrice,
        salePrice: Products.salePrice,
        createdOn: new Date(),
        quantity: Products.quantity,
        size: Products.size,
        color: Products.color,
        productImage: images,
        status: "Available",
      });
      await newProduct.save();
      return res.redirect("/admin/addProducts");
    } else {
      return res
        .status(400)
        .send("Product already exists, please choose a different name.");
    }
  } catch (error) {
    console.error("Error adding product:", error);
    return res.redirect("/admin/pageerror");
  }
};

module.exports = {
  getProductAddPage,
  addProducts,
};
